package com.tencent.igg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;
import org.apache.commons.io.FileUtils;
import java.io.IOException;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import java.io.FileOutputStream;
import java.io.FileReader;

public class SurfaceViewL extends SurfaceView implements SurfaceHolder.Callback, Runnable
{
	// SurfaceHolder
	private SurfaceHolder mSurfaceHolder;
	// 画布
	private Canvas mCanvas;
	// 子线程标志位
	private boolean isDrawing;

	private Paint mPaint;

	private String PATH;

	private Handler mHandler;


    Paint paint=new Paint();
    Paint paint1=new Paint();
    Paint paint2=new Paint();
    Paint paint3=new Paint();
    Paint paint4=new Paint();
    Paint paint5=new Paint();
    
    float x=0;
    float y=0;
    float x1=0;
    float y1=0;
    float w=0;
    float h=0;
    float M=0;
	float hp=0;
    
	private Context mContext;

	public SurfaceViewL(Context context)
	{
		this(context, null);
	}

	public SurfaceViewL(Context context, AttributeSet attrs)
	{
		super(context, attrs);

		this.mContext = context;
		init();
	}

	public  String getFileContent(File file)
	{
		String content = "";
		if (!file.isDirectory())
		{
			try
			{
				InputStream instream = new FileInputStream(file);
				if (instream != null)
				{
					InputStreamReader inputreader
						= new InputStreamReader(instream, "UTF-8");
					BufferedReader buffreader = new BufferedReader(inputreader);
					String line = "";
					while ((line = buffreader.readLine()) != null)
					{
						content += line;
					}
					instream.close();//关闭输入流
				}
			}
			catch (java.io.FileNotFoundException e)
			{
			}
			catch (IOException e)
			{
			}
		}
		return content;
	}
	private void init()
	{
		mHandler = new Handler(mContext.getMainLooper());
		PATH = new File(mContext.getFilesDir(), "temp.txt").getAbsolutePath();
		PATH = "/data/data/com.tencent.igg/files/images/libUE4.so";
	
		mSurfaceHolder = getHolder();
		mSurfaceHolder.addCallback(this);

		this.setZOrderOnTop(true);
		mSurfaceHolder.setFormat(PixelFormat.TRANSLUCENT);
        //paint.setAntiAlias(true);
        paint.setColor(Color.rgb(1, 255, 255));
        paint.setStyle(Paint.Style.FILL);  //方框背景
        paint.setAlpha(50);

        //paint.setDither(true);
        //paint.setFilterBitmap(true);

        //paint1.setAntiAlias(true);
        paint1.setColor(Color.rgb(255, 255, 255));
        paint1.setStyle(Paint.Style.STROKE);  //边框
        paint1.setStrokeWidth(2f);

        //paint1.setDither(true);
        //paint1.setFilterBitmap(true);

        //paint2.setAntiAlias(true);
        paint2.setColor(Color.rgb(255, 52, 25));  //血条
        paint2.setStyle(Paint.Style.FILL);
        paint2.setStrokeWidth(5f);
        paint2.setAlpha(200);

        //paint3.setAntiAlias(true);
        paint3.setColor(Color.rgb(255, 255, 255));  //距离
        paint3.setStyle(Paint.Style.FILL);
        paint3.setStrokeWidth(10f);
        paint3.setTextSize(25);
        paint3.setAlpha(255);

        //paint4.setAntiAlias(true);
        paint4.setColor(Color.rgb(255, 255, 255));  //背敌距离
        paint4.setStyle(Paint.Style.FILL);      
        paint4.setTextSize(25);
        paint4.setAlpha(205);

        //paint5.setAntiAlias(true);
        paint5.setColor(Color.rgb(0, 255, 0));  //背敌
        paint5.setStyle(Paint.Style.FILL);
        paint5.setTextSize(15);
		paint5.setAlpha(130);

        
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder)
	{//创建
		isDrawing = true;
		new Thread(this).start();
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
	{//改变

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{//销毁
		isDrawing = false;
	}

	@Override
	public void run()
	{
		while (isDrawing)
		{  
        if(Date.getA()=="开启和平"){
                hp();
            }else
            if(Date.getA()=="开启王者"){
                wz();
			}
		}
	}

	//绘制带红色圆圈的圆形图片
	private void drawCircleBitmap(Canvas canvas, Bitmap bitmap, float x, float y,int hp, float fx, float fy, float h)
	{
		final int STROKE_WIDTH = 5;

        Paint paint10=new Paint();

        paint10.setColor(Color.rgb(255, 255, 255));
        paint10.setStyle(Paint.Style.STROKE);  //边框
        paint10.setStrokeWidth(2f);
		Paint paint11=new Paint();
		paint11.setColor(Color.argb(250,255,255,255));
		paint11.setStyle(Paint.Style.FILL_AND_STROKE); 
		Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		mPaint.setAntiAlias(true);
		mPaint.setColor(Color.WHITE);
		mCanvas.drawCircle(x + 20, y + 20, 40 / 2, mPaint);
		mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		mCanvas.drawBitmap(bitmap, x, y, mPaint);

		//画圆圈
		mPaint.reset();
		mPaint.setColor(Color.RED);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeWidth(STROKE_WIDTH);
		mPaint.setAntiAlias(true);
		mCanvas.drawCircle(x + 20, y + 20, 40 / 2, mPaint);
		//mCanvas.drawLine(2160/2,1080/2,fx-h+60,fy-h+60,paint10);
		//mCanvas.drawRect(fx-h+60,fy-2*h+60,fx+60,fy+60,paint10);
		mCanvas.drawRect(x,y+42,x+45,y+47,paint11);
		mCanvas.drawRect(x,y+42,x+hp,y+47,mPaint);
	}

	
	private void hp()
	{
		try
		{
			mCanvas = mSurfaceHolder.lockCanvas();

			pubg();

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (mCanvas != null)
			{
				mSurfaceHolder.unlockCanvasAndPost(mCanvas);
			}
		}
	}

    private void wz()
    {
        try
        {
            mCanvas = mSurfaceHolder.lockCanvas();

            drawGameObj();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (mCanvas != null)
            {
                mSurfaceHolder.unlockCanvasAndPost(mCanvas);
            }
        }
	}
    private void pubg(){
        File file = new File("/sdcard/b.log");
        if (file == null)
        {
            return;

        }
        String fileContent = getFileContent(file);
        String[] concent = fileContent.split(";");

	  mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        Log.d("log", "run: " + concent.length);
        for (int i = 0; i < concent.length; i++)
        {
            String[] zb = concent[i].split(",");
            try
            {
                x = Float.parseFloat(zb[0]);
                y = Float.parseFloat(zb[1]);
                w = Float.parseFloat(zb[2]);
                h = Float.parseFloat(zb[3]);
                M = Float.parseFloat(zb[4]);
                hp = Float.parseFloat(zb[5]);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            int m = (int)M;
            if (m < 450 && m > 1 && hp < 121 && hp>0)
            {
                if (x < 0)
                {
                    if (y <= 0)
                    {
                        mCanvas.drawCircle(0, 0, 80, paint5);
                    }
                    else
                    if (y > 1080)
                    {
                        mCanvas.drawCircle(0, 1080, 80, paint5);
                    }
                    else
                    {
                        mCanvas.drawCircle(0, y, 80, paint5);
                        mCanvas.drawText(m + "M", 0, y, paint4);
                    }
                }
                else
                if (x > 2340)
                {
                    if (y <= 0)
                    {
                        mCanvas.drawCircle(2270, 0, 80, paint5);
                    }
                    else
                    if (y > 1080)
                    {
                        mCanvas.drawCircle(2270, 1080, 80, paint5);
                    }
                    else
                    {
                        mCanvas.drawCircle(2270, y, 80, paint5);
                        mCanvas.drawText(m + "M", 2210, y, paint4);
                    }
                }

                if (x < 2340 && x > 0 && y > 0 && w > 0 && h > 0 && hp>0)
                {


                    mCanvas.drawRect(x, y - w, x + w, y + w, paint1);
                    mCanvas.drawRect(x, y - w, x + w, y + w, paint);


                    mCanvas.drawLine(2160/2, 0, x , y -  w , paint1);

                    mCanvas.drawText(m + "M", x , y - w - 10, paint3);

                    mCanvas.drawLine(x + w + 6, y + h / 2, x + w + 6, y - hp / 100 * w * 2 + h / 2, paint2);
                }
            }
        }
	}
	private void drawGameObj()
	{

		File imgDir = new File(mContext.getFilesDir(), "images");
		List<String> lines = null;

        File files = new File("/data/data/com.tencent.igg/files/images/xy.log");
        if (files == null)
        {
            return;

        }
        String xxyy = getFileContent(files);
        String[] xy = xxyy.split(";");
		try
		{
			lines = FileUtils.readLines(new File(PATH));
			if (lines.size() != 0)
			{			
				//清屏

				mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
				for (int i=0; i < lines.size(); i++)
				{
					String[] split = lines.get(i).split(",");

					try
					{
						int id = Integer.parseInt(split[0]);
						float fx = Float.parseFloat(split[1]);
						float fy = Float.parseFloat(split[2]);
						float h = Float.parseFloat(split[3]);
						float x1 = Float.parseFloat(split[4]);
						float y1 = Float.parseFloat(split[5]);
						int hp = Integer.parseInt(split[6]);
                        int xxx = Integer.parseInt(xy[0]);
                        int yyy = Integer.parseInt(xy[1]);
								
						File file = new File(imgDir, id + ".png");
						float x=x1*330/100000+xxx;
						float y= y1*330/100000+yyy;
						Bitmap bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()), 40, 40, true);
						
						if (hp > 0)
						{
							drawCircleBitmap(mCanvas, bitmap, x , y ,hp,fx ,fy, h);
						}
					}
					catch (NumberFormatException e)
					{}
								
				}
			}
		}
		catch (IOException e)
		{
			final String msg = e.getMessage();
			mHandler.post(new Runnable() {

					@Override
					public void run()
					{
						Toast.makeText(mContext, msg, 0).show();
					}
				});
		}
	}
}
