package com.tencent.igg;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;

public class FloatingService extends Service
{

	private FloatView floatView;

	private WindowManager windowManager;

	private FloatingService mContext;

	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		this.mContext = this;
		floatView = new FloatView(this);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		// TODO: Implement this method
		floatView.show();
		return super.onStartCommand(intent, flags, startId);
	}

	
	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
		floatView.dismiss();
	}
	
}
