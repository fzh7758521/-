package com.tencent.igg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.File;
import android.widget.ToggleButton;

public class FloatView extends FrameLayout
{

	private Context mContext;

	private WindowManager windowManager;

	private WindowManager.LayoutParams lp;

	private ImageView mImageView;

	private PopupWindow popupWindow;

	private boolean isShowing;

	public FloatView(Context context)
	{
        super(context);
        init(context);
    }
	private void ExecuteElf(String shell)
	{
		String s=shell;

		try
		{
			Runtime.getRuntime().exec(s,null,null);//执行
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	private void init(Context context)
	{
		// TODO: Implement this method
		this.mContext = context;

		// 创建WindowManager对象
		windowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);

		// 更新浮动窗口位置参数 靠边
        DisplayMetrics dm = new DisplayMetrics();
        // 获取屏幕信息
        windowManager.getDefaultDisplay().getMetrics(dm);
        int mScreenWidth = dm.widthPixels;
        int mScreenHeight = dm.heightPixels;

		// 创建悬浮窗的LayoutParams
		lp = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
		{
            lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
		else
		{
            lp.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		lp.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
		lp.gravity = Gravity.START | Gravity.TOP;	
		lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
		lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
		lp.format = PixelFormat.RGBA_8888;

		/*lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR |
			WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_SECURE;*/
		mScreenHeight = windowManager.getDefaultDisplay().getHeight();

		// 以屏幕左上角为原点，设置x、y初始值，相对于gravity
		lp.x = mScreenWidth;
		lp.y = mScreenHeight/2;

		initNormalView();
		initControlView();
        ExecuteElf("su -c");
		
	}

	//初始化悬浮按钮
	private void initNormalView()
	{
		//悬浮窗
		mImageView = new ImageView(mContext){
			@Override
			public boolean performClick()
			{
				return super.performClick();
			}
		};

		//悬浮窗设置图片

		File imgDir = new File(mContext.getFilesDir(), "images");

	    File file = new File(imgDir,  "bjt.png");
        Bitmap bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()), 60, 60, true);
		mImageView.setImageBitmap(bitmap);
		GradientDrawable gd = new GradientDrawable();
		gd.setColor(Color.GRAY);
		gd.setCornerRadius(30);
		gd.setStroke(1, 0);
		gd.setAlpha(125);
		mImageView.setBackground(gd);

		//悬浮窗触摸事件
		mImageView.setOnTouchListener(new OnTouchListener() {

				private boolean isMove;

				private float downX;

				private float downY;
				
				private float moveX;

				private float moveY;
				@Override
				public boolean onTouch(View view, MotionEvent motionEvent)
				{
					switch (motionEvent.getActionMasked())
					{
						case MotionEvent.ACTION_DOWN:
							isMove = false;
							downX = motionEvent.getRawX();
							downY = motionEvent.getRawY();
							break;
						case MotionEvent.ACTION_MOVE:
							moveX = motionEvent.getRawX() - downX;
							moveY = motionEvent.getRawY() - downY;
							downX += moveX;
							downY += moveY;
							if (moveX > 5 || moveY > 5)
							{
								isMove = true;
							}
							lp.x += (int) (moveX);
							lp.y += (int) (moveY);
							windowManager.updateViewLayout(view, lp);
							break;
						case MotionEvent.ACTION_UP:

							break;
					}
					return false;
				}
			});

		mImageView.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v)
				{
					popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
				}
			});

	}

	//初始化弹窗
	private void initControlView()
	{
		//设置contentView
		View contentView = LayoutInflater.from(mContext).inflate(R.layout.popup_control_view, null);
		popupWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		popupWindow.setContentView(contentView);
		//设置弹窗样式
		GradientDrawable gd = new GradientDrawable();
		gd.setColor(Color.BLACK);
		gd.setCornerRadius(30);
		gd.setStroke(1, 0);
		gd.setAlpha(100);
		popupWindow.setBackgroundDrawable(gd);

		//点窗口外关闭	
		popupWindow.setFocusable(true);
		//全局弹出
		popupWindow.setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);

		///初始化控件
		Button mBtnClose = contentView.findViewById(R.id.ib_close);
		mBtnClose.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					ExecuteElf("su -c /data/data/com.tencent.igg/files/images/libsgame.so");
					Toast.makeText(mContext, "二进制正在执行", Toast.LENGTH_SHORT).show();
		
				}
			});

        ///初始化控件
        Button hpjy = contentView.findViewById(R.id.ib_hpjy);
        hpjy.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View p1)
                {
                    ExecuteElf("su -c /data/data/com.tencent.igg/files/images/pung");
                    Toast.makeText(mContext, "二进制正在执行", Toast.LENGTH_SHORT).show();

                }
			});
		Button qx = contentView.findViewById(R.id.ib_szqx);
		qx.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					ExecuteElf("su -c chmod 777 /data/data/com.tencent.igg/files/images/xy.log");
					ExecuteElf("su -c chmod 777 /data/data/com.tencent.igg/files/images/pubg");
					ExecuteElf("su -c chmod 777 /data/data/com.tencent.igg/files/images/libUE4.so");
					ExecuteElf("su -c chmod 777 /data/data/com.tencent.igg/files/images/libsgame.so");
					Toast.makeText(mContext, "初始化软件，设置权限", Toast.LENGTH_SHORT).show();
					

				}
			});
		

		//开关
		final ToggleButton mSwSgame = contentView.findViewById(R.id.sw_sgame);
		mSwSgame.setOnCheckedChangeListener(new OnCheckedChangeListener() {	

				//绘制界面
				private View mSurfaceView;
				//绘制悬浮窗的参数
				private WindowManager.LayoutParams params;
				private WindowManager mWm;
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					if (isChecked)
					{		
						mWm = (WindowManager)mContext.getSystemService(Context.WINDOW_SERVICE);
						params = new WindowManager.LayoutParams();
						params.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;   			// 设置window type
						params.format = PixelFormat.RGBA_8888;   			// 设置图片格式，效果为背景透明
						params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; 	// 设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
						params.gravity = Gravity.LEFT | Gravity.TOP;		// 调整悬浮窗显示的停靠位置为左侧置顶
						params.x = 0;
						params.y = 0;
						params.width = 2160;
						params.height = 1080;

						new Thread(new Runnable(){

								@Override
								public void run()
								{
									// TODO: Implement this method

								}
							}).start();

						mSurfaceView = new SurfaceViewL(mContext);
						mWm.addView(mSurfaceView, params);
                        Date.setA("开启王者");
						Toast.makeText(mContext, "头像已开启", Toast.LENGTH_SHORT).show();
					}
					else
					{
						mWm.removeView(mSurfaceView);
						Toast.makeText(mContext, "头像已关闭", Toast.LENGTH_SHORT).show();
					}
				}
			});

        //开关
        final ToggleButton game = contentView.findViewById(R.id.sw_game);
        game.setOnCheckedChangeListener(new OnCheckedChangeListener() { 

                //绘制界面
                private View mSurfaceView;
                //绘制悬浮窗的参数
                private WindowManager.LayoutParams params;
                private WindowManager mWm;
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
                {
                    if (isChecked)
                    {       
                        mWm = (WindowManager)mContext.getSystemService(Context.WINDOW_SERVICE);
                        params = new WindowManager.LayoutParams();
                        params.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;               // 设置window type
                        params.format = PixelFormat.RGBA_8888;              // 设置图片格式，效果为背景透明
                        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;     // 设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
                        params.gravity = Gravity.LEFT | Gravity.TOP;        // 调整悬浮窗显示的停靠位置为左侧置顶
                        params.x = 0;
                        params.y = 0;
                        params.width = 2160;
                        params.height = 1080;

                        new Thread(new Runnable(){

                                @Override
                                public void run()
                                {
                                    // TODO: Implement this method

                                }
                            }).start();

                        mSurfaceView = new SurfaceViewL(mContext);
                        mWm.addView(mSurfaceView, params);
                        Date.setA("开启和平");
                        Toast.makeText(mContext, "方框已开启", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        mWm.removeView(mSurfaceView);
                        Toast.makeText(mContext, "方框已关闭", Toast.LENGTH_SHORT).show();
                    }
                }
			});
	}

	public void show()
	{
		if (!isShowing)
		{
			isShowing = true;
			windowManager.addView(mImageView, lp);
		}
	}

	public void dismiss()
	{
		if (isShowing)
		{
            isShowing = false;
            windowManager.removeView(mImageView);
        }
	}
	
	/**
	 * 应用程序运行命令获取 Root权限，设备必须已破解(获得ROOT权限)
	 * 
	 * @return 应用程序是/否获取Root权限
	 */
	public static boolean upgradeRootPermission(String cmd) {
		Process process = null;
		DataOutputStream os = null;
		try {

			process = Runtime.getRuntime().exec("su"); //切换到root帐号
			os = new DataOutputStream(process.getOutputStream());
			os.writeBytes(cmd + "\n");
			os.writeBytes("exit\n");
			os.flush();
			process.waitFor();
		} catch (Exception e) {
			return false;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
				process.destroy();
			} catch (Exception e) {
			}
		}
		return true;
	}
}
