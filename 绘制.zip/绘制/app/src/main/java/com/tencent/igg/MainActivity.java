package com.tencent.igg;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import com.tencent.igg.R;
import java.io.File;

public class MainActivity extends Activity implements View.OnClickListener
{

	private Button mStart;
	private Button mStop;


    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		//初始化图片缓存
		initImages();

		//请求悬浮窗权限
		applyAlertPermission();

		mStart = findViewById(R.id.btn_start_usage);
		mStop = findViewById(R.id.btn_stop_service);

		mStart.setOnClickListener(this);
		mStop.setOnClickListener(this);

    }

	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.btn_start_usage:
				startService(new Intent(MainActivity.this, FloatingService.class));
				finish();
				break;
			case R.id.btn_stop_service:
				stopService(new Intent(MainActivity.this, FloatingService.class));
				finish();
				break;
		}
	}

	
	private void initImages()
	{
		new Thread(new Runnable() {
				@Override
				public void run()
				{
					File dir = new File(getFilesDir(), "images");
					if (!dir.exists())
					{
						dir.mkdir();
						try
						{
							ZipUtils.UnZipAssetsFolder(getApplicationContext(), "images.zip", dir.getAbsolutePath());
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}
				}
			}).start();
	}

	private void applyAlertPermission()
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			//判断是否 有悬浮窗的权限
			if (!Settings.canDrawOverlays(getApplicationContext()))
			{
				AlertDialog dialog = new AlertDialog.Builder(this)
					.setTitle("无法显示悬浮窗")//设置对话框的标题
					.setMessage("请在下一个界面授权本应用")//设置对话框的内容
					.setNegativeButton("忽略", null)
					.setPositiveButton("确定", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
							startActivity(intent);
						}
					}).create();
				dialog.show();
			}
		}
	}


}
