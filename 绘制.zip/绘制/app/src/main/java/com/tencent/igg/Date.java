package com.tencent.igg;

public class Date
{
    private static String a ="feiyangxiaomi";

    public static String getA() {
        return a;
    }

    public static void setA(String a) {
        Date.a = a;
    }
}

