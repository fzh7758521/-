git remote add origingit@github.com:fzh7758521/-.git
git push -u origin master

